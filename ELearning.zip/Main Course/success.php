<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/styles.css">
    <title>Success</title>
</head>
<body>
    <div class="l-form">
        <div class="form">
            <h2 class="form__title">Registration Successful!</h2>
            <p>Thank you for signing up. You can now <a href="login.html">log in</a>.</p>
        </div>
    </div>
</body>
</html>
