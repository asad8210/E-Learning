function validateForm(formId) {
    const form = document.getElementById(formId);
    const inputs = form.querySelectorAll('input, select');
    let isValid = true;

    inputs.forEach(input => {
        if (input.required && !input.value) {
            isValid = false;
            input.classList.add('border-red-500'); // Highlight invalid fields
        } else {
            input.classList.remove('border-red-500'); // Remove highlight for valid fields
        }
    });

    return isValid;
}

// Modify the payment buttons to include validation
document.querySelectorAll('.payment-form button[type="submit"]').forEach(button => {
    button.addEventListener('click', function (event) {
        const formId = this.closest('.payment-form').id;
        if (!validateForm(formId)) {
            event.preventDefault(); // Prevent form submission if invalid
            alert('Please fill out all required fields.');
        }
    });
});


const monthSelect = document.getElementById('month');
for (let i = 1; i <= 12; i++) {
    const option = document.createElement('option');
    option.value = i < 10 ? '0' + i : i; // Format as '01', '02', etc.
    option.textContent = option.value; // Display as '01', '02', etc.
    monthSelect.appendChild(option);
}

// Populate year options
const yearSelect = document.getElementById('year');
for (let year = new Date().getFullYear(); year <= 2035; year++) {
    const option = document.createElement('option');
    option.value = year; // Year value
    option.textContent = year; // Display year
    yearSelect.appendChild(option);
}


// Function to generate random Enrollment ID
function generateEnrollmentId() {
    const prefix = 'R';
    const suffix = 'C';
    const randomNum1 = Math.floor(100 + Math.random() * 900); // Random 3-digit number
    const randomNum2 = Math.floor(100 + Math.random() * 900); // Random 3-digit number
    return `${prefix}${randomNum1}${suffix}${randomNum2}`;
}

// Assign the generated ID to the div
document.getElementById('enrollmentDiv').innerHTML = `Enrollment id="${generateEnrollmentId()}"`;
function setEnrollmentId() {
    const enrollmentId = generateEnrollmentId();
    localStorage.setItem('enrollmentId', enrollmentId); // Store in localStorage
    document.getElementById('enrollmentId').innerText = enrollmentId; // Show on page
}

// Call the function when the page loads
window.onload = setEnrollmentId;
