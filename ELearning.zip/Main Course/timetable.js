const Sunday =[
    {   
        time: 'Sunday',
        roomNumber: 'Holiday',
        subject: 'No class Enjoy😊',
        type: ''
    }
]
const Monday =[
    {   
        time: '10:30 AM-11:20 AM',
        roomNumber: 'SMART CLASS 10',
        subject: 'CNS(NT)',
        type: 'Lecture'
    },
    {   
        time: '11:20 AM-12:10 AM',
        roomNumber: 'SMART CLASS 10',
        subject: 'ANN(TV)',
        type: 'Lecture'
    },
    {   
        time: '12:10 PM-01:00 PM',
        roomNumber: 'SMART CLASS 10',
        subject: 'ANN(TV)',
        type: 'Lecture'
    },
    {   
        time: '01:00 PM-01:50 PM',
        roomNumber: 'SMART CLASS 10',
        subject: 'CC(NT)',
        type: 'Lecture'
    },
    {   
        time: '01:50 PM-02:40 PM',
        roomNumber: 'SC10/ CANTEEN',
        subject: 'LUNCH',
        type: 'LUNCH',

    },
    {   
        time: '02:40 PM-03:30 PM',
        roomNumber: 'SMART CLASS 10',
        subject: 'MPIT(AJ)',
        type: 'Lecture'
    },
    {   
        time: '03:30 PM-04:20 PM',
        roomNumber: 'SMART CLASS 10',
        subject: 'MPIT(AJ)',
        type: 'Lecture'
    },
    {   
        time: '04:20 PM- 05:00 PM',
        roomNumber: 'SMART CLASS 10',
        subject: 'MPIT(AJ)',
        type: 'Lecture'
    }




]
const Tuesday =[
    {   
        time: '10-11 AM',
        roomNumber: '38-605E',
        subject: 'CAP213',
        type: 'Tutorial'
    },
    {   
        time: '11-12 AM',
        roomNumber: '38-605E',
        subject: 'CAP214',
        type: 'Lecture'
    },
    {   
        time: '12-01 PM',
        roomNumber: '38-605E',
        subject: 'CAP267',
        type: 'Lecture'
    },
    {   
        time: '03-04 PM',
        roomNumber: '38-801',
        subject: 'ECE281',
        type: 'Lecture'
    },
    {   
        time: '12-01 PM',
        roomNumber: '38-801',
        subject: 'PES209',
        type: 'Lecture'
    }

]

const Wednesday =[
    {   
        time: '10-11 AM',
        roomNumber: '38-605E',
        subject: 'CAP213',
        type: 'Lecture'
    },
    {   
        time: '11-12 AM',
        roomNumber: '38-605E',
        subject: 'CAP214',
        type: 'Lecture'
    },
    {   
        time: '12-01 PM',
        roomNumber: '38-605E',
        subject: 'CAP267',
        type: 'Lecture'
    },
    {   
        time: '03-04 PM',
        roomNumber: '38-801',
        subject: 'ECE281',
        type: 'Lecture'
    },
    {   
        time: '12-01 PM',
        roomNumber: '38-801',
        subject: 'PES209',
        type: 'Tutorial'
    }
]

const Thursday =[
    {   
        time: '11-12 AM',
        roomNumber: '38-605E',
        subject: 'CAP213',
        type: 'Lecture'
    },
    {   
        time: '12-01 PM',
        roomNumber: '38-612',
        subject: 'CAP282',
        type: 'Practical'
    },
    {   
        time: '02-03 PM',
        roomNumber: '38-612',
        subject: 'CAP283',
        type: 'Practical'
    },
    {   
        time: '03-04 PM',
        roomNumber: '33-110',
        subject: 'ECE281',
        type: 'Practical'
    },
    {   
        time: '04-05 PM',
        roomNumber: '38-801',
        subject: 'PES209',
        type: 'Tutorial'
    }
]

const Friday =[
    {   
        time: '12-01 AM',
        roomNumber: '38-612',
        subject: 'CAP282',
        type: 'Practical'
    },
    {   
        time: '01-02 PM',
        roomNumber: '38-612',
        subject: 'CAP283',
        type: 'Practical'
    },
    {   
        time: '03-04 PM',
        roomNumber: '38-605E',
        subject: 'CAP214',
        type: 'Lecture'
    },

]

const Saturday =[
    {   
        time: 'N/A',
        roomNumber: 'N/A',
        subject: 'CHECK MAKEUP CLASSES 😒',
        type: 'N/A'
    }
]