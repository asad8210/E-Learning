<?php
include('db_connection.php'); // This includes your connection file

if ($conn) {
    echo "Connected successfully";
}
?>
