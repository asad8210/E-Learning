/*===== FOCUS AND BLUR FUNCTIONALITY =====*/
const inputs = document.querySelectorAll(".form__input");

/*=== Add focus class to parent container ===*/
function handleFocus() {
    const parent = this.closest(".form__div");
    parent.classList.add("focus");
}

/*=== Remove focus class if input is empty ===*/
function handleBlur() {
    const parent = this.closest(".form__div");
    if (this.value.trim() === "") {
        parent.classList.remove("focus");
    }
}

/*=== Attach focus and blur events to each input ===*/
inputs.forEach(input => {
    input.addEventListener("focus", handleFocus);
    input.addEventListener("blur", handleBlur);
});
