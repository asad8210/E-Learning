<?php
include('db_connection.php');

// Get token and new password from the form
$token = htmlspecialchars(trim($_POST['token']));
$password = htmlspecialchars(trim($_POST['password']));
$confirmPassword = htmlspecialchars(trim($_POST['confirmPassword']));

// Validate passwords
if (empty($password) || empty($confirmPassword)) {
    echo "Password fields are required.";
} elseif ($password !== $confirmPassword) {
    echo "Passwords do not match.";
} else {
    // Hash the new password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Verify the token and update the password
    $stmt = $conn->prepare("UPDATE userinfo SET password = ?, reset_token = NULL WHERE reset_token = ?");
    $stmt->bind_param("ss", $hashedPassword, $token);
    
    if ($stmt->execute()) {
        echo "Password has been reset successfully.";
        header("Location: login.html"); // Redirect to login after successful reset
    } else {
        echo "Invalid or expired token.";
    }

    $stmt->close();
    $conn->close();
}
?>
