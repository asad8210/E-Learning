<?php
include('db_connection.php'); // Include the database connection

// Collect and sanitize input data
$name = htmlspecialchars(trim($_POST['username'])); 
$email = htmlspecialchars(trim($_POST['email']));
$password = htmlspecialchars(trim($_POST['password']));
$confirmPassword = htmlspecialchars(trim($_POST['confirmPassword']));

// Validate inputs
$errors = [];

if (empty($name)) {
    $errors[] = "Username is required.";
}
if (empty($email)) {
    $errors[] = "Email is required.";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email format.";
}
if (empty($password)) {
    $errors[] = "Password is required.";
}
if ($password !== $confirmPassword) {
    $errors[] = "Passwords do not match.";
}

// If no validation errors, proceed with inserting data
if (empty($errors)) {
    // Hash the password before saving it to the database
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL statement to insert data
    $stmt = $conn->prepare("INSERT INTO userinfo (userid, name, email, password) VALUES (?, ?, ?, ?)");
    
    // Generate a unique userid (you can use any method, e.g., UUID)
    $userid = uniqid();
    
    $stmt->bind_param("ssss", $userid, $name, $email, $hashedPassword);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect to the login page after successful sign-up
        header("Location: login.html");
        exit();
    } else {
        // Handle SQL error
        $errors[] = "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} 

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/styles.css">
    <title>Sign Up</title>
</head>
<body>
    <div class="l-form">
        <div class="form">
            <h2 class="form__title">Sign Up</h2>
            <?php if (!empty($errors)): ?>
                <div class="error-messages">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="signup.php" method="POST" class="form__content">
                <div class="form__div form__div-one">
                    <div class="form__div-input">
                        <label for="username" class="form__label">Username</label>
                        <input type="text" id="username" name="username" class="form__input" value="<?php echo isset($name) ? $name : ''; ?>" required>
                    </div>
                </div>

                <div class="form__div">
                    <div class="form__div-input">
                        <label for="email" class="form__label">Email</label>
                        <input type="email" id="email" name="email" class="form__input" value="<?php echo isset($email) ? $email : ''; ?>" required>
                    </div>
                </div>

                <div class="form__div">
                    <div class="form__div-input">
                        <label for="password" class="form__label">Password</label>
                        <input type="password" id="password" name="password" class="form__input" required>
                    </div>
                </div>

                <div class="form__div">
                    <div class="form__div-input">
                        <label for="confirmPassword" class="form__label">Confirm Password</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" class="form__input" required>
                    </div>
                </div>

                <input type="submit" class="form__button" value="Sign Up">
            </form>

            <div class="form__signup">
                <span class="form__signup-text">Already have an account?</span>
                <a href="login.html" class="form__signup-link">Login</a>
            </div>
        </div>
    </div>
</body>
</html>
