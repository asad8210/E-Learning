<?php
// Include the PHPMailer library files
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Ensure the PHPMailer files are included correctly
require 'PHPMailer-master/PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/PHPMailer-master/src/SMTP.php';

// Include the database connection
include('db_connection.php');

// Collect and sanitize email input
$email = htmlspecialchars(trim($_POST['email']));

// Validate email
if (empty($email)) {
    echo "Email is required.";
    exit;
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format.";
    exit;
} else {
    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT * FROM userinfo WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email exists, generate reset token
        $token = bin2hex(random_bytes(32));
        $resetLink = "https://yourdomain.com/reset-password.php?token=" . $token;

        // Store the reset token in the database
        $stmt = $conn->prepare("UPDATE userinfo SET reset_token = ? WHERE email = ?");
        $stmt->bind_param("ss", $token, $email);
        if (!$stmt->execute()) {
            echo "Failed to save reset token: " . $stmt->error;
            exit;
        }

        // Send the reset link via PHPMailer
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Gmail SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'your_email@gmail.com'; // Your Gmail address
        $mail->Password = 'your_app_password'; // Your Gmail App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('your_email@gmail.com', 'Your Website');
        $mail->addAddress($email); // Add recipient email

        $mail->isHTML(true);  // Set email format to HTML
        $mail->Subject = 'Password Reset Request';
        $mail->Body = "Click the following link to reset your password: <a href='$resetLink'>$resetLink</a>";

        if ($mail->send()) {
            echo "Password reset link has been sent to your email.";
        } else {
            echo "Mailer Error: " . $mail->ErrorInfo;
        }
    } else {
        echo "No account found with that email address.";
    }

    // Close the connection and statement
    $stmt->close();
    $conn->close();
}
?>
