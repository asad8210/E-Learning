<?php
// Start session to use session variables
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";  // Update this with your database username
$password = "";      // Update this with your database password
$dbname = "course";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize form inputs
    $user = htmlspecialchars(trim($_POST['username']));
    $pass = htmlspecialchars(trim($_POST['password']));

    // Ensure the input fields are not empty
    if (empty($user) || empty($pass)) {
        echo "Username and password are required.";
        exit();
    }

    // SQL query to fetch the user with matching username
    $sql = "SELECT * FROM userinfo WHERE name = ?";  // Assuming 'name' column is used for usernames in the DB
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user);  // Bind parameters for security

    // Execute query
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows > 0) {
        // Fetch user data
        $row = $result->fetch_assoc();

        // Verify the password
        if (password_verify($pass, $row['password'])) {
            // Successful login
            $_SESSION['username'] = $user;  // Set session variable for logged-in user
            $_SESSION['userid'] = $row['userid']; // Set the user's ID in the session

            // Redirect to homepage or dashboard
            header("Location: index.html");
            exit();
        } else {
            // Incorrect password
            echo "<p>Incorrect password.</p>";
        }
    } else {
        // No user found with that username
        echo "<p>No user found with that username.</p>";
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>
