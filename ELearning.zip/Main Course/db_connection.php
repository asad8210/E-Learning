<?php
$servername = "localhost"; // Use 'localhost' for local server
$username = "root"; // Default username in XAMPP is usually 'root'
$password = ""; // Default password in XAMPP is empty, so leave this as an empty string
$dbname = "course"; // Use the actual database name 'course'

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
